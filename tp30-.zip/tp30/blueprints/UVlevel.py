from flask import Blueprint, render_template, request, redirect,flash
import random

bp = Blueprint("uv",__name__,url_prefix="/uv")

@bp.route("/uv")
def uvinfor():
    return render_template("uv.html")


@bp.route("/serach", methods=['get','post'])
def search():
    if request.form.get("location") == "Select Location" or request.form.get("dateinput") == "":
        flash("Please select 'Location' and 'Date'.")
        return redirect("/")
    baseL = int(request.form.get("location"))
    baseY = int(request.form.get("dateinput").split("-")[0])
    baseM = int(request.form.get("dateinput").split("-")[1])
    baseD = int(request.form.get("dateinput").split("-")[2])
    if baseM > 8:
        level = baseL+(baseY-2020)/10000-12+baseM+random.random()*baseD/10
    else:
        level = baseL + (baseY - 2020) / 10000 - baseM + random.random() * baseD/10
    if level > 8:
        flash("UV value: " + str(level) + " UV Level: High")
    elif level > 4:
        flash("UV value: " + str(level) + " UV Level: Medium")
    else:
        flash("UV value: " + str(level) + " UV Level: Low")
    return redirect("/")